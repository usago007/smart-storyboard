#!/bin/bash

echo "=== 广告对白分镜工具完整功能测试 ==="

PORT=$(echo $DEPLOY_RUN_PORT)
BASE_URL="http://localhost:${PORT}"

echo "1. 测试服务是否运行..."
curl -s "$BASE_URL" > /dev/null
if [ $? -eq 0 ]; then
    echo "✅ 服务运行正常"
else
    echo "❌ 服务未运行"
    exit 1
fi

echo ""
echo "2. 测试分镜拆分API..."
SCENE_RESULT=$(curl -s -X POST "$BASE_URL/api/split-scenes" \
    -H "Content-Type: application/json" \
    -d '{
        "script":"每天坚持使用，肌肤焕发自然光彩。温和配方，深层滋养，让美丽从内而外绽放。选择我们，选择自信与美丽。这不仅仅是一款护肤品，更是您日常护肤的好伴侣。",
        "duration":10,
        "targetWordsPerScene":89
    }')

echo "$SCENE_RESULT" | jq '.' > /dev/null 2>&1
if [ $? -eq 0 ]; then
    echo "✅ 分镜拆分API正常"
    echo "   分镜数量: $(echo "$SCENE_RESULT" | jq '.scenes | length')"
else
    echo "❌ 分镜拆分API异常"
    echo "$SCENE_RESULT"
fi

echo ""
echo "3. 测试镜头提示词生成..."
SHOT_RESULT=$(curl -s -X POST "$BASE_URL/api/generate-shot-prompt" \
    -H "Content-Type: application/json" \
    -d '{
        "sceneId":1,
        "dialogue":"每天坚持使用，肌肤焕发自然光彩。",
        "duration":10
    }')

echo "$SHOT_RESULT" | jq '.' > /dev/null 2>&1
if [ $? -eq 0 ] && [[ "$SHOT_RESULT" == *"success\":true"* ]]; then
    echo "✅ 镜头提示词生成正常"
else
    echo "❌ 镜头提示词生成异常"
    echo "$SHOT_RESULT"
fi

echo ""
echo "4. 测试首帧提示词生成..."
FIRST_FRAME_RESULT=$(curl -s -X POST "$BASE_URL/api/generate-frames" \
    -H "Content-Type: application/json" \
    -d '{
        "sceneId":1,
        "dialogue":"每天坚持使用，肌肤焕发自然光彩。",
        "duration":10,
        "frameType":"first"
    }')

echo "$FIRST_FRAME_RESULT" | jq '.' > /dev/null 2>&1
if [ $? -eq 0 ] && [[ "$FIRST_FRAME_RESULT" == *"success\":true"* ]]; then
    echo "✅ 首帧提示词生成正常"
    FIRST_SCENE=$(echo "$FIRST_FRAME_RESULT" | jq -r '.first_frame.scene_description')
    echo "   场景描述: ${FIRST_SCENE:0:50}..."
else
    echo "❌ 首帧提示词生成异常"
    echo "$FIRST_FRAME_RESULT"
fi

echo ""
echo "5. 测试尾帧提示词生成..."
LAST_FRAME_RESULT=$(curl -s -X POST "$BASE_URL/api/generate-frames" \
    -H "Content-Type: application/json" \
    -d '{
        "sceneId":1,
        "dialogue":"每天坚持使用，肌肤焕发自然光彩。",
        "duration":10,
        "frameType":"last"
    }')

echo "$LAST_FRAME_RESULT" | jq '.' > /dev/null 2>&1
if [ $? -eq 0 ] && [[ "$LAST_FRAME_RESULT" == *"success\":true"* ]]; then
    echo "✅ 尾帧提示词生成正常"
    LAST_SCENE=$(echo "$LAST_FRAME_RESULT" | jq -r '.last_frame.scene_description')
    echo "   场景描述: ${LAST_SCENE:0:50}..."
else
    echo "❌ 尾帧提示词生成异常"
    echo "$LAST_FRAME_RESULT"
fi

echo ""
echo "6. 测试URL导入功能..."
URL_RESULT=$(curl -s -X POST "$BASE_URL/api/fetch-url" \
    -H "Content-Type: application/json" \
    -d '{"url":"https://example.com"}')

echo "$URL_RESULT" | jq '.' > /dev/null 2>&1
if [ $? -eq 0 ] && [[ "$URL_RESULT" == *"success\":true"* ]]; then
    echo "✅ URL导入功能正常"
    CONTENT_LENGTH=$(echo "$URL_RESULT" | jq -r '.content | length')
    echo "   导入内容长度: $CONTENT_LENGTH 字符"
else
    echo "❌ URL导入功能异常"
    echo "$URL_RESULT"
fi

echo ""
echo "=== 测试完成 ==="
echo "🌐 应用地址: $BASE_URL"
echo "请手动测试以下功能:"
echo "  - 文件上传 (点击'📁 文件上传'按钮)"
echo "  - 语音输入 (点击'🎤 语音输入'按钮)"
echo "  - 预设模板 (点击'📋 预设模板'按钮)"