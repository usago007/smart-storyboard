const { Pool } = require('pg');
const pool = new Pool({ connectionString: process.env.DATABASE_URL });

async function debugSessionManager() {
  const client = await pool.connect();
  try {
    const sessionId = 'manual_1766809343785_66l93bju7';
    
    console.log('Current time:', new Date().toISOString());
    
    const result = await client.query(
      'SELECT * FROM user_generation_sessions WHERE session_id = $1 AND expires_at > $2',
      [sessionId, new Date()]
    );
    
    console.log('Direct query result:', result.rows);
    
  } catch (error) {
    console.error('Error:', error);
  } finally {
    client.release();
    await pool.end();
  }
}

debugSessionManager();