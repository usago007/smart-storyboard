#!/bin/bash

# 设置测试数据到sessionStorage (通过curl模拟)
# 由于curl无法直接设置sessionStorage，我们需要通过一个测试页面来设置

echo "正在准备测试数据..."

# 创建一个临时测试文件来设置sessionStorage
cat > /tmp/set_test_data.html << 'EOF'
<!DOCTYPE html>
<html>
<head>
    <title>设置测试数据</title>
</head>
<body>
    <script>
        // 设置测试分镜数据
        const testData = {
            scenes: [
                {
                    id: 1,
                    duration: 10,
                    dialogue: "欢迎使用广告对白分镜工具，这是一个测试对白。",
                    shotPrompt: "产品展示特写镜头，突出产品特点",
                    firstFramePrompt: "明亮的产品包装特写",
                    lastFramePrompt: "产品与用户互动场景"
                },
                {
                    id: 2,
                    duration: 5,
                    dialogue: "第二个分镜的测试对白内容。",
                    shotPrompt: "人物使用产品的场景",
                    firstFramePrompt: "用户开心使用产品",
                    lastFramePrompt: "产品效果展示"
                }
            ]
        };
        
        // 保存到sessionStorage
        sessionStorage.setItem('splitterResult', JSON.stringify(testData));
        
        // 显示成功信息
        document.body.innerHTML = '<h1>测试数据已设置</h1><p>请访问 /result 页面查看效果</p><p><a href="/result">查看结果页面</a></p>';
        
        console.log('测试数据已保存到sessionStorage:', testData);
    </script>
</body>
</html>
EOF

echo "测试数据文件已创建，请访问 http://localhost:3000/tmp/set_test_data.html 来设置测试数据"