ALTER TABLE user_generation_sessions ADD COLUMN IF NOT EXISTS scene_type VARCHAR(20) DEFAULT 'auto' NOT NULL;
ALTER TABLE user_generation_sessions ADD COLUMN IF NOT EXISTS source_data JSONB;
CREATE INDEX IF NOT EXISTS user_generation_sessions_scene_type_idx ON user_generation_sessions(scene_type);