#!/bin/bash

echo "=== 广告对白分镜工具完整功能测试 ==="

PORT=$(echo $DEPLOY_RUN_PORT)
BASE_URL="http://localhost:${PORT}"

echo "1. 测试服务是否运行..."
curl -s "$BASE_URL" > /dev/null
if [ $? -eq 0 ]; then
    echo "✅ 服务运行正常"
else
    echo "❌ 服务未运行"
    exit 1
fi

echo ""
echo "2. 测试分镜拆分API..."
SCENE_RESULT=$(curl -s -X POST "$BASE_URL/api/split-scenes" \
    -H "Content-Type: application/json" \
    -d '{
        "script":"每天坚持使用，肌肤焕发自然光彩。温和配方，深层滋养，让美丽从内而外绽放。选择我们，选择自信与美丽。这不仅仅是一款护肤品，更是您日常护肤的好伴侣。",
        "duration":10,
        "targetWordsPerScene":89
    }')

echo "$SCENE_RESULT" | python3 -m json.tool > /dev/null 2>&1
if [ $? -eq 0 ]; then
    echo "✅ 分镜拆分API正常"
    echo "   分镜数量: $(echo "$SCENE_RESULT" | python3 -c "import sys, json; data=json.load(sys.stdin); print(len(data.get('scenes', [])))")"
else
    echo "❌ 分镜拆分API异常"
    echo "$SCENE_RESULT"
fi

echo ""
echo "3. 测试镜头提示词生成..."
SHOT_RESULT=$(curl -s -X POST "$BASE_URL/api/generate-shot-prompt" \
    -H "Content-Type: application/json" \
    -d '{
        "sceneId":1,
        "dialogue":"每天坚持使用，肌肤焕发自然光彩。",
        "duration":10
    }')

echo "$SHOT_RESULT" | python3 -m json.tool > /dev/null 2>&1
if [ $? -eq 0 ] && [[ "$SHOT_RESULT" == *"success\":true"* ]]; then
    echo "✅ 镜头提示词生成正常"
else
    echo "❌ 镜头提示词生成异常"
    echo "$SHOT_RESULT"
fi

echo ""
echo "=== 测试完成 ==="
echo "🌐 应用地址: $BASE_URL"