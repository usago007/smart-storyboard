# 广告对白智能分镜工具 - API接口文档

## 📋 项目概述

本项目是一个基于Next.js 16的广告对白智能分镜工具，集成了多种AI服务，提供从文案拆分到分镜生成的完整解决方案。

- **技术栈**: Next.js 16.0.10, TypeScript, Tailwind CSS, PostgreSQL, Drizzle ORM
- **AI平台**: 豆包大模型 (Coze)
- **数据库**: PostgreSQL + 24小时自动清理
- **部署环境**: 支持容器化部署

---

## 🛠️ API接口总览

### 1. 分镜相关API

| 接口路径 | 方法 | 功能描述 | 大模型 | 数据库 | 输入参数 |
|---------|------|----------|--------|--------|----------|
| `/api/split-scenes` | POST | 将广告对白按时长智能拆分为分镜 | ❌ 算法拆分 | ❌ | script, duration, targetWordsPerScene |
| `/api/generate-shot-prompt` | POST | 生成专业镜头提示词 | ✅ doubao-seed-1-6-251015 | ❌ | sceneId, dialogue, duration |
| `/api/generate-frames` | POST | 生成首尾帧详细拍摄指导 | ✅ doubao-seed-1-6-251015 | ❌ | sceneId, dialogue, duration, frameType |
| `/api/batch-generate` | POST | 批量生成提示词(镜头/首尾帧) | ✅ doubao-seed-1-6-251015 | ❌ | scenes[], type |

### 2. 文案处理API

| 接口路径 | 方法 | 功能描述 | 大模型 | 数据库 | 输入参数 |
|---------|------|----------|--------|--------|----------|
| `/api/polish-script` | POST | AI智能润色广告文案表达 | ✅ doubao-seed-1-6-251015 | ❌ | script |

### 3. 图片生成API

| 接口路径 | 方法 | 功能描述 | 大模型 | 数据库 | 输入参数 |
|---------|------|----------|--------|--------|----------|
| `/api/generate-image` | POST | 生成1:1黑白手绘风格图片 | ✅ doubao-seedream-4-5-251128 | ✅ | sessionId, sceneId, frameType, prompt, forceRegenerate |

### 4. 数据管理API

| 接口路径 | 方法 | 功能描述 | 大模型 | 数据库 | 说明 |
|---------|------|----------|--------|--------|------|
| `/api/database/session` | GET/POST | 获取/创建用户会话数据 | ❌ | ✅ | 支持会话持久化 |
| `/api/database/cleanup` | GET/POST | 数据清理统计/手动触发清理 | ❌ | ✅ | 24小时自动过期 |

### 5. 工具类API

| 接口路径 | 方法 | 功能描述 | 大模型 | 数据库 | 输入参数 |
|---------|------|----------|--------|--------|----------|
| `/api/fetch-url` | POST | 获取指定URL的网页内容 | ❌ | ❌ | url |
| `/api/test-data` | GET | 返回测试分镜数据 | ❌ | ❌ | 无 |

---

## 🤖 大模型配置详情

### 文本生成模型

#### 主模型配置
- **模型名称**: `doubao-seed-1-6-251015`
- **服务提供商**: 豆包 (Coze平台)
- **API基础地址**: `process.env.COZE_INTEGRATION_MODEL_BASE_URL`
- **认证方式**: Bearer Token (`process.env.COZE_WORKLOAD_IDENTITY_API_KEY`)

#### 各服务详细配置

| 服务名称 | Max Tokens | Temperature | 流式输出 | 特殊配置 |
|---------|------------|-------------|----------|----------|
| 镜头提示词生成 | 2000 | 0.7 | ✅ 启用 | 强制200-400字输出 |
| 首尾帧生成 | 1500 | 0.7 | ✅ 启用 | JSON格式返回 |
| 文案润色 | 1500 | 0.8 | ✅ 启用 | 高创造性 |
| 批量生成 | 2000 | 0.7 | ✅ 启用 | 串行处理 |

### 图片生成模型

#### 主模型配置
- **模型名称**: `doubao-seedream-4-5-251128`
- **服务提供商**: 豆包 (Coze平台)
- **API基础地址**: `process.env.COZE_INTEGRATION_BASE_URL`

#### 图片生成特性
| 特性 | 配置值 | 说明 |
|------|--------|------|
| 图片尺寸 | 3840x3840 | 1:1正方形比例 |
| 图片风格 | 铅笔手绘 | 后处理增强 |
| 色彩模式 | 强制黑白 | Sharp库处理 |
| 负面提示词 | "彩色，色彩，颜色..." | 避免彩色元素 |
| 水印 | 关闭 | clean输出 |
| 输出格式 | URL/base64 | 支持两种格式 |

#### 图片后处理流程
1. **下载原始图片**: 从Coze获取高清图片
2. **尺寸优化**: 调整为1024x1024减少体积
3. **黑白转换**: Sharp库灰度化 + 对比度增强
4. **Base64编码**: 转换为base64格式存储
5. **数据库存储**: 保存到PostgreSQL text字段

---

## 🗄️ 数据库设计

### 数据库类型
- **主数据库**: PostgreSQL
- **ORM框架**: Drizzle ORM
- **连接管理**: 连接池 + 自动重连
- **数据清理**: 24小时自动过期清理

### 数据表结构

#### 1. user_generation_sessions (用户生成会话表)

| 字段名 | 数据类型 | 长度/约束 | 说明 | 索引 |
|--------|----------|-----------|------|------|
| id | varchar | 36 | 主键，UUID格式 | PRIMARY |
| sessionId | varchar | 255 | 会话唯一标识 | ✅ |
| userFingerprint | text | - | 用户指纹标识 | ✅ |
| scriptContent | text | - | 原始广告对白内容 | - |
| duration | integer | - | 分镜时长(5/10/12秒) | - |
| scenes | jsonb | - | 分镜数据(JSON格式) | - |
| createdAt | timestamp | with timezone | 创建时间 | - |
| expiresAt | timestamp | with timezone | 过期时间(24小时) | ✅ |

#### 2. image_generations (图片生成记录表)

| 字段名 | 数据类型 | 长度/约束 | 说明 | 索引 |
|--------|----------|-----------|------|------|
| id | varchar | 36 | 主键，UUID格式 | PRIMARY |
| sessionId | varchar | 255 | 关联会话ID | ✅ |
| sceneId | integer | - | 分镜ID | ✅ |
| frameType | varchar | 10 | 帧类型(first/last) | ✅ |
| prompt | text | - | 生成提示词 | - |
| imageUrl | text | - | 图片URL(base64格式) | - |
| generationTime | integer | - | 生成耗时(毫秒) | - |
| status | varchar | 20 | 状态(pending/generating/success/failed) | ✅ |
| errorMessage | text | - | 错误信息 | - |
| createdAt | timestamp | with timezone | 创建时间 | - |
| expiresAt | timestamp | with timezone | 过期时间(24小时) | ✅ |

### 数据库特性

#### 🔒 安全特性
- **临时存储**: 所有数据24小时后自动过期
- **会话隔离**: 每个用户会话完全独立
- **数据加密**: 敏感信息加密存储
- **访问控制**: 基于sessionId的访问控制

#### ⚡ 性能特性
- **索引优化**: 关键查询字段建立索引
- **连接池**: 数据库连接复用
- **批量操作**: 支持批量插入和查询
- **并发控制**: 支持多用户同时访问

#### 🧹 清理机制
- **自动清理**: 每小时执行一次过期数据清理
- **手动清理**: 支持管理员手动触发清理
- **统计监控**: 实时监控清理状态和数据量
- **错误恢复**: 清理失败自动重试机制

---

## 🔄 数据流向图

```
用户输入 → API接口 → 处理逻辑 → 结果输出
    ↓
[分镜拆分] → 算法处理 → JSON结果 → 前端展示
    ↓
[提示词生成] → 大模型API → 流式输出 → 实时显示
    ↓
[图片生成] → 豆包生图 → 黑白处理 → 数据库存储 → Base64返回
    ↓
[会话管理] → PostgreSQL → 24小时过期 → 自动清理
```

---

## 📊 API响应格式

### 成功响应格式
```json
{
  "success": true,
  "data": {
    // 具体数据内容
  }
}
```

### 错误响应格式
```json
{
  "success": false,
  "error": "错误描述信息"
}
```

### 特殊响应格式

#### 图片生成缓存
```json
{
  "success": true,
  "imageUrl": "base64://...",
  "generationTime": 2500,
  "cached": true
}
```

#### 批量生成进度
```json
{
  "success": true,
  "results": [...],
  "errors": [...],
  "total": 10,
  "success_count": 8,
  "error_count": 2,
  "completed_scenes": [1, 2, 3, 5, 7, 8, 9, 10]
}
```

---

## 🔧 环境变量配置

### 必需环境变量

```bash
# 大模型服务配置
COZE_WORKLOAD_IDENTITY_API_KEY=your_api_key
COZE_INTEGRATION_MODEL_BASE_URL=https://api.coze.com
COZE_INTEGRATION_BASE_URL=https://api.coze.com

# 数据库配置
DATABASE_URL=postgresql://user:password@localhost:5432/dbname

# 可选模型配置
SHOT_PROMPT_MODEL=doubao-seed-1-6-251015
FRAMES_MODEL=doubao-seed-1-6-251015
POLISH_SCRIPT_MODEL=doubao-seed-1-6-251015
BATCH_MODEL=doubao-seed-1-6-251015
```

---

## 📈 性能指标

### 响应时间
- **分镜拆分**: < 100ms (算法处理)
- **镜头提示词**: 3-8秒 (流式输出)
- **首尾帧生成**: 5-12秒 (JSON结构化)
- **文案润色**: 2-6秒 (流式输出)
- **图片生成**: 10-25秒 (含后处理)
- **数据查询**: < 50ms (数据库索引)

### 并发能力
- **最大并发用户**: 100+
- **API并发请求**: 500/分钟
- **数据库连接池**: 20个连接
- **图片处理队列**: 10个并发

### 存储容量
- **单会话数据**: ~10KB
- **单图片存储**: ~200KB (base64)
- **日峰值存储**: ~500MB
- **自动清理周期**: 24小时

---

## 🛡️ 安全措施

### API安全
- **输入验证**: Zod schema严格验证
- **SQL注入防护**: Drizzle ORM参数化查询
- **XSS防护**: 输出内容转义
- **CSRF防护**: Next.js内置保护

### 数据安全
- **临时存储**: 24小时自动过期
- **数据加密**: 敏感字段加密
- **访问控制**: 会话级别的数据隔离
- **审计日志**: 操作记录追踪

---

## 📝 更新日志

### v1.2.0 (最新)
- ✅ 优化镜头提示词生成，提升内容详细度
- ✅ 修复图片重新生成功能
- ✅ 实现图片强制黑白转换
- ✅ 扩展字符限制从500到800字

### v1.1.0
- ✅ 添加批量生成功能
- ✅ 实现数据库临时存储
- ✅ 集成豆包生图模型
- ✅ 添加图片黑白处理

### v1.0.0
- ✅ 基础分镜拆分功能
- ✅ AI提示词生成
- ✅ 移动端适配
- ✅ 多语言支持

---

## 📞 技术支持

如有技术问题，请查看以下资源：
- **API文档**: 本文档
- **错误码说明**: 参考API响应
- **性能监控**: 数据库清理统计接口
- **日志查看**: 服务器应用日志

---

*最后更新时间: 2025年12月26日*
*文档版本: v1.2.0*