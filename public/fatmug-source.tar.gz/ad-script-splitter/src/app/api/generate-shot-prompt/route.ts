import { NextRequest, NextResponse } from 'next/server';
import { ChatOpenAI } from '@langchain/openai';
import { SystemMessage, HumanMessage } from '@langchain/core/messages';

interface GenerateShotPromptRequest {
  sceneId: number;
  dialogue: string;
  duration: number;
}

async function callLLM(messages: any[], config: any) {
  const apiKey = process.env.COZE_WORKLOAD_IDENTITY_API_KEY;
  const baseURL = process.env.COZE_INTEGRATION_MODEL_BASE_URL;
  
  if (!baseURL || !apiKey) {
    throw new Error("Missing environment variables");
  }

  const llm = new ChatOpenAI({
    modelName: config.model || "doubao-seed-1-6-251015",
    apiKey: apiKey,
    configuration: {
      baseURL: baseURL,
    },
    streaming: true,
    temperature: config.temperature || 0.7,
    maxTokens: config.max_tokens || 1000,
    modelKwargs: {
      thinking: {
        type: "disabled",
      },
    },
  });

  const stream = await llm.stream(messages);
  let fullContent = "";
  for await (const chunk of stream) {
    fullContent += chunk.content;
  }
  return fullContent;
}

export async function POST(request: NextRequest) {
  try {
    const { sceneId, dialogue, duration }: GenerateShotPromptRequest = await request.json();

    if (!dialogue || !duration) {
      return NextResponse.json(
        { success: false, error: '缺少必要参数' },
        { status: 400 }
      );
    }

    console.log(`开始生成分镜${sceneId}的镜头提示词...`);

    // 构建镜头提示词生成的prompt
    const shotPrompt = await callLLM([
      new SystemMessage(`请为以下广告分镜生成详细且专业的镜头提示词，用于指导视频制作团队。

分镜信息：
- 分镜编号：${sceneId}
- 分镜对白："${dialogue}"
- 分镜时长：${duration}秒

请生成一个精简的镜头提示词（严格控制在500字符以内），必须包含以下要素：
1. 场景设置（简述环境、背景）
2. 角色表演（动作、表情、情绪）
3. 镜头语言（景别、角度、运动）
4. 视觉风格（色调、光线、构图）
5. 关键道具和细节

要求：
- 严格控制在500字符以内（含标点符号）
- 语言要精炼专业，便于制作团队执行
- 要符合分镜时长的节奏要求
- 要与对白内容高度匹配
- 避免冗余描述，突出核心信息

请直接返回镜头提示词内容，不要添加任何解释或格式标记：`),
      new HumanMessage(`请为以下分镜生成镜头提示词（500字符以内）：分镜${sceneId}，对白："${dialogue}"，${duration}秒`)
    ], {
      model: "doubao-seed-1-6-251015",
      temperature: 0.7,
      max_tokens: 800
    });

    if (!shotPrompt) {
      throw new Error('LLM返回的镜头提示词为空');
    }

    // 强制截断到500字符
    const maxLength = 500;
    const truncatedShotPrompt = shotPrompt.length > maxLength 
      ? shotPrompt.substring(0, maxLength) 
      : shotPrompt;

    console.log(`分镜${sceneId}镜头提示词生成完成，长度：${truncatedShotPrompt.length}字符`);

    return NextResponse.json({
      success: true,
      shot_prompt: truncatedShotPrompt
    });

  } catch (error) {
    console.error('生成镜头提示词失败:', error);
    return NextResponse.json(
      { success: false, error: '生成镜头提示词失败，请重试' },
      { status: 500 }
    );
  }
}