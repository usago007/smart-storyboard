import { eq, and, lt, count } from "drizzle-orm";
import { getDb } from "./db";
import { 
  imageGenerations, 
  insertImageGenerationSchema, 
  updateImageGenerationSchema,
  type ImageGeneration,
  type InsertImageGeneration,
  type UpdateImageGeneration 
} from "./shared/schema";

export interface ImageGenerationOptions {
  sessionId: string;
  sceneId: number;
  frameType: 'first' | 'last';
  prompt: string;
}

export interface GenerationResult {
  success: boolean;
  imageUrl?: string;
  generationTime?: number;
  error?: string;
}

export class ImageGenerationManager {
  private readonly MAX_CONCURRENT_PER_SESSION = 3;
  private readonly MAX_CONCURRENT_GLOBAL = 50;

  /**
   * 创建图片生成记录
   */
  async createGenerationRecord(options: ImageGenerationOptions): Promise<ImageGeneration> {
    const db = await getDb();
    const recordData: InsertImageGeneration = {
      sessionId: options.sessionId,
      sceneId: options.sceneId,
      frameType: options.frameType,
      prompt: options.prompt,
    };

    const validatedData = insertImageGenerationSchema.parse(recordData);
    const [record] = await db.insert(imageGenerations).values(validatedData).returning();
    
    return record;
  }

  /**
   * 获取图片生成记录
   */
  async getGenerationRecord(sessionId: string, sceneId: number, frameType: 'first' | 'last'): Promise<ImageGeneration | null> {
    const db = await getDb();
    const [record] = await db
      .select()
      .from(imageGenerations)
      .where(and(
        eq(imageGenerations.sessionId, sessionId),
        eq(imageGenerations.sceneId, sceneId),
        eq(imageGenerations.frameType, frameType)
      ))
      .orderBy(imageGenerations.createdAt)
      .limit(1);
    
    return record || null;
  }

  /**
   * 更新生成记录状态
   */
  async updateGenerationRecord(
    id: string, 
    updates: UpdateImageGeneration
  ): Promise<ImageGeneration | null> {
    const db = await getDb();
    
    try {
      // 验证数据
      const validatedData = updateImageGenerationSchema.parse(updates);
      
      console.log('准备更新数据库记录:', { 
        id, 
        hasImageUrl: !!validatedData.imageUrl,
        imageUrlLength: validatedData.imageUrl?.length || 0,
        status: validatedData.status 
      });
      
      const [record] = await db
        .update(imageGenerations)
        .set(validatedData)
        .where(eq(imageGenerations.id, id))
        .returning();
      
      console.log('数据库更新成功:', { 
        id, 
        updated: !!record,
        imageUrlLength: record?.imageUrl?.length || 0 
      });
      
      return record || null;
    } catch (error) {
      console.error('数据库更新失败:', {
        id,
        error: error instanceof Error ? error.message : error,
        updates: {
          hasImageUrl: !!updates.imageUrl,
          imageUrlLength: updates.imageUrl?.length || 0,
          status: updates.status
        }
      });
      
      throw error;
    }
  }

  /**
   * 更新生成成功状态
   */
  async markGenerationSuccess(
    id: string, 
    imageUrl: string, 
    generationTime: number
  ): Promise<boolean> {
    try {
      const result = await this.updateGenerationRecord(id, {
        imageUrl,
        generationTime,
        status: 'success'
      });
      
      console.log('图片生成记录更新成功:', { 
        id, 
        imageUrlLength: imageUrl.length,
        isBase64: imageUrl.startsWith('data:'),
        generationTime 
      });
      
      return result !== null;
    } catch (error) {
      console.error('更新生成记录失败:', error);
      
      // 如果是因为imageUrl太大导致的失败，尝试只更新状态而不更新URL
      if (imageUrl.startsWith('data:') && imageUrl.length > 1000000) {
        console.warn('图片URL过大，尝试更新状态而不更新URL');
        try {
          const result = await this.updateGenerationRecord(id, {
            imageUrl: '[BASE64_IMAGE_TOO_LARGE]', // 使用占位符
            generationTime,
            status: 'success'
          });
          return result !== null;
        } catch (fallbackError) {
          console.error('备用的更新也失败:', fallbackError);
        }
      }
      
      return false;
    }
  }

  /**
   * 更新生成失败状态
   */
  async markGenerationFailure(id: string, errorMessage: string): Promise<boolean> {
    const result = await this.updateGenerationRecord(id, {
      status: 'failed',
      errorMessage
    });
    
    return result !== null;
  }

  /**
   * 标记生成中状态
   */
  async markGenerationInProgress(id: string): Promise<boolean> {
    const result = await this.updateGenerationRecord(id, {
      status: 'generating'
    });
    
    return result !== null;
  }

  /**
   * 检查是否可以获取生成资源
   */
  async acquireGenerationSlot(sessionId: string): Promise<{
    canProceed: boolean;
    estimatedWaitTime?: number;
    reason?: string;
  }> {
    const db = await getDb();
    
    // 检查当前会话的并发数
    const sessionConcurrent = await db
      .select({ count: count() })
      .from(imageGenerations)
      .where(and(
        eq(imageGenerations.sessionId, sessionId),
        eq(imageGenerations.status, 'generating')
      ));
    
    const sessionCount = sessionConcurrent[0]?.count || 0;
    if (sessionCount >= this.MAX_CONCURRENT_PER_SESSION) {
      return { 
        canProceed: false, 
        reason: '当前会话生成任务过多，请稍后再试' 
      };
    }
    
    // 检查全局并发数
    const globalConcurrent = await db
      .select({ count: count() })
      .from(imageGenerations)
      .where(eq(imageGenerations.status, 'generating'));
    
    const globalCount = globalConcurrent[0]?.count || 0;
    const loadRatio = globalCount / this.MAX_CONCURRENT_GLOBAL;
    
    if (globalCount >= this.MAX_CONCURRENT_GLOBAL) {
      return { 
        canProceed: false, 
        reason: '系统繁忙，请稍后再试' 
      };
    }
    
    // 估算等待时间
    let estimatedWaitTime: number | undefined;
    if (loadRatio > 0.7) {
      estimatedWaitTime = Math.ceil(loadRatio * 15); // 秒
    }
    
    return { 
      canProceed: true, 
      estimatedWaitTime 
    };
  }

  /**
   * 获取指定会话的所有生成记录
   */
  async getSessionGenerations(sessionId: string): Promise<ImageGeneration[]> {
    const db = await getDb();
    return db
      .select()
      .from(imageGenerations)
      .where(eq(imageGenerations.sessionId, sessionId))
      .orderBy(imageGenerations.createdAt);
  }

  /**
   * 获取指定分镜的生成记录
   */
  async getSceneGenerations(sessionId: string, sceneId: number): Promise<ImageGeneration[]> {
    const db = await getDb();
    return db
      .select()
      .from(imageGenerations)
      .where(and(
        eq(imageGenerations.sessionId, sessionId),
        eq(imageGenerations.sceneId, sceneId)
      ))
      .orderBy(imageGenerations.createdAt);
  }

  /**
   * 获取系统负载信息
   */
  async getSystemLoad(): Promise<{
    currentGenerating: number;
    maxConcurrent: number;
    loadPercentage: number;
    sessionGenerating: number;
  }> {
    const db = await getDb();
    
    // 全局生成中的任务数
    const globalResult = await db
      .select({ count: count() })
      .from(imageGenerations)
      .where(eq(imageGenerations.status, 'generating'));
    
    // 当前会话生成中的任务数
    const sessionResult = await db
      .select({ count: count() })
      .from(imageGenerations)
      .where(and(
        eq(imageGenerations.status, 'generating'),
        // 这里需要传入具体的sessionId，暂时返回0
        eq(imageGenerations.sessionId, '')
      ));
    
    const currentGenerating = globalResult[0]?.count || 0;
    const sessionGenerating = sessionResult[0]?.count || 0;
    const loadPercentage = (currentGenerating / this.MAX_CONCURRENT_GLOBAL) * 100;
    
    return {
      currentGenerating,
      maxConcurrent: this.MAX_CONCURRENT_GLOBAL,
      loadPercentage: Math.round(loadPercentage),
      sessionGenerating
    };
  }

  /**
   * 生成完整的图片提示词（添加铅笔手绘风格，仅限黑白）
   */
  enhancePromptForPencilSketch(basePrompt: string): string {
    const stylePrompt = "黑白铅笔手绘素描画，单色线条艺术，传统素描技法，1:1比例正方形构图，只有黑色线条和白色背景，绝对不能有彩色，完全无彩色，纯黑白，铅笔素描风格，线条画，不使用任何彩色元素，灰度图像，单色图像，黑白照片";
    
    if (basePrompt.trim()) {
      return `黑白素描风格，${basePrompt}，${stylePrompt}，严格要求黑白两色，无任何彩色成分，纯黑线条白底，灰度模式，monochrome`;
    }
    
    return `${stylePrompt}，严格要求黑白两色，无任何彩色成分，纯黑线条白底，灰度模式，monochrome`;
  }

  /**
   * 检查生成的图片URL是否有效
   */
  async validateImageUrl(imageUrl: string): Promise<boolean> {
    try {
      const response = await fetch(imageUrl, { method: 'HEAD' });
      return response.ok && (response.headers.get('content-type') || '').startsWith('image/');
    } catch (error) {
      return false;
    }
  }

  /**
   * 将彩色图片转换为黑白（通过灰度化处理）
   * 注意：这里返回原始URL，因为实际的图片处理需要在前端或专门的图片处理服务中进行
   * 在当前环境下，我们只能通过更严格的提示词来确保黑白效果
   */
  async convertToBlackWhite(imageUrl: string): Promise<string | null> {
    try {
      // 在实际环境中，这里应该：
      // 1. 下载图片
      // 2. 转换为灰度
      // 3. 上传到图床
      // 4. 返回新的URL
      
      // 但由于当前环境限制，我们返回null表示无法处理
      // 前端可以显示一个警告，提示用户图片可能需要手动转换为黑白
      console.log('注意：当前环境下无法自动转换图片为黑白，请确保生成的图片符合要求');
      return null;
    } catch (error) {
      console.error('转换黑白失败:', error);
      return null;
    }
  }

  /**
   * 删除指定的生成记录
   */
  async deleteGenerationRecord(id: string): Promise<boolean> {
    const db = await getDb();
    const result = await db.delete(imageGenerations).where(eq(imageGenerations.id, id));
    return (result.rowCount ?? 0) > 0;
  }

  /**
   * 清理过期的生成记录
   */
  async cleanupExpiredRecords(): Promise<number> {
    const db = await getDb();
    const result = await db
      .delete(imageGenerations)
      .where(lt(imageGenerations.expiresAt, new Date()));
    
    return result.rowCount || 0;
  }
}

// 导出单例实例
export const imageGenerationManager = new ImageGenerationManager();