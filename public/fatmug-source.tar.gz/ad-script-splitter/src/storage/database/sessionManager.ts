import { eq, and, lt, gt } from "drizzle-orm";
import { getDb } from "./db";
import { 
  userGenerationSessions, 
  insertUserGenerationSessionSchema, 
  updateUserGenerationSessionSchema,
  type UserGenerationSession,
  type InsertUserGenerationSession,
  type UpdateUserGenerationSession 
} from "./shared/schema";

export class SessionManager {
  private sessionId: string;
  private userFingerprint: string;
  
  constructor() {
    this.sessionId = this.getOrCreateSessionId();
    this.userFingerprint = this.generateFingerprint();
  }

  /**
   * 获取或创建会话ID
   */
  private getOrCreateSessionId(): string {
    if (typeof window === 'undefined') {
      // 服务端生成临时会话ID
      return `server_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
    }
    
    // 优先从sessionStorage获取，否则生成新的
    let sessionId = sessionStorage.getItem('ad_script_session');
    if (!sessionId) {
      sessionId = `session_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
      sessionStorage.setItem('ad_script_session', sessionId);
    }
    return sessionId;
  }

  /**
   * 生成用户指纹（基于浏览器特征）
   */
  private generateFingerprint(): string {
    if (typeof window === 'undefined') {
      return 'server_fingerprint';
    }
    
    try {
      const parts = [
        navigator.userAgent || '',
        screen.width + 'x' + screen.height,
        new Date().getTimezoneOffset().toString(),
        navigator.language || ''
      ];
      return btoa(parts.join('|')).substr(0, 32);
    } catch (error) {
      return 'unknown_fingerprint';
    }
  }

  /**
   * 获取当前会话ID
   */
  getSessionId(): string {
    return this.sessionId;
  }

  /**
   * 获取用户指纹
   */
  getUserFingerprint(): string {
    return this.userFingerprint;
  }

  /**
   * 创建新的生成会话
   */
  async createSession(data: {
    scriptContent: string;
    duration: number;
    scenes: any;
    sessionId?: string; // 可选的自定义sessionId
    sceneType?: string; // 'auto' | 'manual'
    sourceData?: any; // 手工创建时的原始数据
  }): Promise<UserGenerationSession> {
    const db = await getDb();
    const sessionData: InsertUserGenerationSession = {
      sessionId: data.sessionId || this.sessionId,
      userFingerprint: this.userFingerprint,
      scriptContent: data.scriptContent,
      duration: data.duration,
      scenes: data.scenes,
    };

    const validatedData = insertUserGenerationSessionSchema.parse(sessionData);
    const [session] = await db.insert(userGenerationSessions).values(validatedData).returning();
    
    // 如果有额外的字段（sceneType, sourceData），需要单独更新
    if (data.sceneType || data.sourceData || data.sessionId) {
      const updateData: any = {};
      if (data.sceneType) updateData.sceneType = data.sceneType;
      if (data.sourceData) updateData.sourceData = data.sourceData;
      
      const [updatedSession] = await db
        .update(userGenerationSessions)
        .set(updateData)
        .where(eq(userGenerationSessions.id, session.id))
        .returning();
      
      return updatedSession;
    }
    
    return session;
  }

  /**
   * 获取当前会话
   */
  async getCurrentSession(): Promise<UserGenerationSession | null> {
    const db = await getDb();
    const [session] = await db
      .select()
      .from(userGenerationSessions)
      .where(and(
        eq(userGenerationSessions.sessionId, this.sessionId),
        // 修复：应该是gt而不是lt，表示过期时间大于当前时间（未过期）
        gt(userGenerationSessions.expiresAt, new Date())
      ))
      .orderBy(userGenerationSessions.createdAt)
      .limit(1);
    
    return session || null;
  }

  /**
   * 更新会话数据
   */
  async updateSession(data: UpdateUserGenerationSession): Promise<UserGenerationSession | null> {
    const db = await getDb();
    const validatedData = updateUserGenerationSessionSchema.parse(data);
    
    const [session] = await db
      .update(userGenerationSessions)
      .set(validatedData)
      .where(eq(userGenerationSessions.sessionId, this.sessionId))
      .returning();
    
    return session || null;
  }

  /**
   * 删除当前会话
   */
  async deleteCurrentSession(): Promise<boolean> {
    const db = await getDb();
    const result = await db
      .delete(userGenerationSessions)
      .where(eq(userGenerationSessions.sessionId, this.sessionId));
    
    const success = (result.rowCount ?? 0) > 0;
    
    // 清理本地sessionStorage
    if (success && typeof window !== 'undefined') {
      sessionStorage.removeItem('ad_script_session');
    }
    
    return success;
  }

  /**
   * 从数据库恢复会话数据
   */
  async restoreFromDatabase(sessionId?: string): Promise<UserGenerationSession | null> {
    const targetSessionId = sessionId || this.sessionId;
    const db = await getDb();
    
    const [session] = await db
      .select()
      .from(userGenerationSessions)
      .where(and(
        eq(userGenerationSessions.sessionId, targetSessionId),
        gt(userGenerationSessions.expiresAt, new Date())
      ))
      .orderBy(userGenerationSessions.createdAt)
      .limit(1);
    
    return session || null;
  }

  /**
   * 根据scene_type查询会话
   */
  async getSessionByType(sceneType: 'auto' | 'manual'): Promise<UserGenerationSession | null> {
    const db = await getDb();
    
    const [session] = await db
      .select()
      .from(userGenerationSessions)
      .where(and(
        eq(userGenerationSessions.sessionId, this.sessionId),
        eq(userGenerationSessions.sceneType, sceneType),
        gt(userGenerationSessions.expiresAt, new Date())
      ))
      .orderBy(userGenerationSessions.createdAt)
      .limit(1);
    
    return session || null;
  }

  /**
   * 检查会话是否存在且有效
   */
  async isSessionValid(): Promise<boolean> {
    const session = await this.getCurrentSession();
    return session !== null;
  }

  /**
   * 延长会话过期时间（24小时）
   */
  async extendSession(): Promise<boolean> {
    const db = await getDb();
    const newExpiresAt = new Date();
    newExpiresAt.setHours(newExpiresAt.getHours() + 24);
    
    const result = await db
      .update(userGenerationSessions)
      .set({ expiresAt: newExpiresAt })
      .where(eq(userGenerationSessions.sessionId, this.sessionId));
    
    return (result.rowCount ?? 0) > 0;
  }
}

// 导出单例实例
export const sessionManager = new SessionManager();